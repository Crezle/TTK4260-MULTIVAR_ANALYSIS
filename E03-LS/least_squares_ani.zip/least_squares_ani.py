

monomers = [0.34, 0.34, 0.58, 1.26, 1.26] # x0
dimmer   = [0.73, 0.73, 0.69, 0.97, 0.97] # x1
impurity = [5.75, 4.79, 5.44, 9.09, 8.59] # y


def mse(theta0, theta1, x0, x1, y0):
    cost = 0.0
    for idx, y in enumerate(y0):
        cost += (y - theta0*x0[idx] - theta1*x1[idx])**2
    return cost

def dmse_dtheta0(theta0, theta1, x0, x1, y0):
    return sum([-2*x0[i]*(y-theta0*x0[i]-theta1*x1[i]) for i, y in enumerate(y0)])

def dmse_dtheta1(theta0, theta1, x0, x1, y0):
    return sum([-2*x1[i]*(y-theta0*x0[i]-theta1*x1[i]) for i, y in enumerate(y0)])


init_theta0 = -7
init_theta1 = -7
theta0_steps = [init_theta0]
theta1_steps = [init_theta1]

MAX_STEP = 10000
THRESHOLD = 0.01
ALPHA = 0.01

step_counter = 0
while True:
    ddtheta0 = dmse_dtheta0(theta0_steps[-1], theta1_steps[-1], monomers, dimmer, impurity)
    ddtheta1 = dmse_dtheta1(theta0_steps[-1], theta1_steps[-1], monomers, dimmer, impurity)
    theta0_steps.append(theta0_steps[-1] - ALPHA*ddtheta0)
    theta1_steps.append(theta1_steps[-1] - ALPHA*ddtheta1)

    step_counter += 1
    if ddtheta0**2 + ddtheta1**2 < THRESHOLD:
        print("Below threshold for change")
        break
    if step_counter > MAX_STEP:
        print("Exceeded MAX_STEP number of steps.")
        break


# plot function
from matplotlib import cm, animation
from matplotlib import pyplot as plt
import numpy as np

fig = plt.figure()

# subplot of cost function and steps
theta0_space = np.linspace(-10, 10, 100)
theta1_space = np.linspace(-10, 20, 100)

X, Y = np.meshgrid(theta0_space, theta1_space)
Z = mse(X, Y, monomers, dimmer, impurity)

ax1 = fig.add_subplot(1, 2, 1, projection='3d')
ax1.contour(X, Y, Z, levels=200, cmap=cm.coolwarm)

steps_scatter = ax1.scatter(theta0_steps[0], theta1_steps[0], mse(np.array(theta0_steps[0]),np.array(theta1_steps[0]), monomers, dimmer, impurity), color='black')
ax1.set_xlabel(r"$\theta_0$")
ax1.set_ylabel(r"$\theta_1$")

# subplot of regression plane
ax2 = fig.add_subplot(1, 2, 2, projection="3d")
ax2.scatter(monomers, dimmer, impurity, color='blue')
ax2.set_xlabel(r"$x_0$")
ax2.set_ylabel(r"$x_1$")

x0_space = np.linspace(min(monomers), max(monomers), 100)
x1_space = np.linspace(min(dimmer), max(dimmer), 100)
X0, X1 = np.meshgrid(x0_space, x1_space)

model = theta0_steps[0]*X0 + theta1_steps[0]*X1
model_surf = ax2.plot_surface(X0, X1, model, color="orange")


## ANIMATION ##

def update_scatter(num):
    '''https://stackoverflow.com/questions/41602588/matplotlib-3d-scatter-animations'''
    theta0_steps_ani = theta0_steps[0:num+1] 
    theta1_steps_ani = theta1_steps[0:num+1]
    steps_scatter._offsets3d = (theta0_steps_ani, theta1_steps_ani, mse(np.array(theta0_steps_ani),np.array(theta1_steps_ani), monomers, dimmer, impurity))

def update_surface(num, surface):
    '''https://www.tutorialspoint.com/how-to-animate-3d-plot-surface-in-matplotlib'''
    latest_theta0 = theta0_steps[num]
    latest_theta1 = theta1_steps[num]

    model = latest_theta0*X0 + latest_theta1*X1
    new_model_surf = ax2.plot_surface(X0, X1, model, color="orange")

    surface[0].remove()
    surface[0] = new_model_surf

def update_figure(num, surface):
    update_scatter(num)
    update_surface(num, surface)

ani = animation.FuncAnimation(fig, update_figure, fargs=([model_surf], ), interval=500, blit=False)

plt.show()
